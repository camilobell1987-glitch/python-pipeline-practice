# Python pipeline practice

Your 10-week path from tutorials to building a data pipeline from scratch.

| Step | Weeks | Focus | Project |
|---|---|---|---|
| 1 | 1–3 | Python for real scripts | Clean a messy CSV from the terminal |
| 2 | 4–6 | pandas, APIs, SQL, logging | API → clean → database |
| 3 | 7–10 | Build a full pipeline | One shaped like your colleagues' |

## Before you start (about 1 hour)

1. Install **Python 3.12 or newer** from python.org. On Windows, tick "Add Python to PATH".
2. Install **VS Code** and its **Python** extension.
3. Install **git** (git-scm.com), then tell it who you are:
   ```
   git config --global user.name "Your Name"
   git config --global user.email "you@example.com"
   ```
4. Download this `python-pipeline-practice` folder and open it in VS Code.
5. Put it on GitHub. On github.com click **New repository**, name it
   `python-pipeline-practice`, leave every box unticked, create it, then in the
   VS Code terminal (inside this folder) run:
   ```
   git init
   git add .
   git commit -m "Start week 1"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/python-pipeline-practice.git
   git push -u origin main
   ```
   After each exercise, save your progress with
   `git add . && git commit -m "Finish exercise 1" && git push`.

## Week 1 (about 12 hours)

Work inside the `week1` folder. Open the terminal there and run each file with
`python ex1_functions.py` (use `python3` on Mac). Fill in every `...` until all
checks say **PASS**.

| Session | File | What you practise |
|---|---|---|
| ~2h | `ex1_functions.py` | Functions, arguments, defaults, return values |
| ~2h | `ex2_lists_dicts.py` | Lists, dicts, loops, grouping data |
| ~2h | `ex3_files.py` | Reading CSV, writing JSON, file paths |
| ~2h | `ex4_errors.py` | try/except, handling bad values |
| ~4h | `clean_sales.py` | Your first mini pipeline, run from the terminal |

Answers are in `week1/solutions`, but give each exercise a real try first.
When you're done, or stuck, tell me in the thread and I'll review your code and
set up week 2.
