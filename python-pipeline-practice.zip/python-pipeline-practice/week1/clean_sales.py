"""Week 1 project: your first mini pipeline.

Read data/messy_sales.csv, clean it, and write data/clean_sales.csv.
Run it from the terminal:  python clean_sales.py data/messy_sales.csv data/clean_sales.csv

Open the messy file first and spot the problems. Your cleaned file should:
  1. Drop duplicate order_ids (keep the first one).
  2. Trim spaces and title-case customer and product names ("  ana lopez " -> "Ana Lopez").
  3. Turn every date into YYYY-MM-DD (some are DD/MM/YYYY).
  4. Skip rows with no customer, a bad quantity, or a bad price,
     and print a short line saying which order was skipped and why.
  5. Add a `total` column (quantity * unit_price, 2 decimal places).
  6. Print a summary at the end: rows read, duplicates dropped, rows skipped, rows written.

Reuse your functions from exercises 1, 3 and 4. Copy them in, or import them:
    from ex4_errors import to_number, to_quantity
You should end up with 5 clean rows (10 read, 1 duplicate, 4 skipped).
"""
import sys


def main(input_path, output_path):
    ...


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python clean_sales.py INPUT.csv OUTPUT.csv")
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
