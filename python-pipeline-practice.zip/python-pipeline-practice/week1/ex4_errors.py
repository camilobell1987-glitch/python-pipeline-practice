"""Exercise 4: handling bad data without crashing.

Real data is messy. A pipeline should skip or flag a bad value, not fall over.
Run:  python ex4_errors.py
"""


def to_number(text):
    """Turn text like " 12.50 " into 12.5. Return None if it isn't a number
    (e.g. "twelve" or ""). Use try/except ValueError.
    """
    ...


def to_quantity(text):
    """Return a positive whole number, or None if the text is empty, not a
    whole number, or zero/negative.  "3" -> 3, "-1" -> None, "" -> None
    """
    ...


def check(label, got, expected):
    print(("PASS" if got == expected else "FAIL"), label, "| got:", repr(got), "| expected:", repr(expected))


if __name__ == "__main__":
    check("to_number ok", to_number(" 12.50 "), 12.5)
    check("to_number word", to_number("twelve"), None)
    check("to_number empty", to_number(""), None)
    check("to_quantity ok", to_quantity("3"), 3)
    check("to_quantity negative", to_quantity("-1"), None)
    check("to_quantity empty", to_quantity(""), None)
    check("to_quantity decimal", to_quantity("2.5"), None)
