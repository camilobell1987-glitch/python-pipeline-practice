"""Exercise 2: lists and dictionaries, the shapes most pipeline data takes.

Run:  python ex2_lists_dicts.py
"""

ORDERS = [
    {"customer": "Ana", "product": "Coffee Beans", "total": 25.0},
    {"customer": "Ben", "product": "Tea Box", "total": 8.0},
    {"customer": "Ana", "product": "Mug", "total": 6.75},
    {"customer": "Chloe", "product": "Coffee Beans", "total": 37.5},
]


def customers(orders):
    """Return a sorted list of unique customer names."""
    ...


def big_orders(orders, minimum):
    """Return only the orders whose total is >= minimum (same order as input)."""
    ...


def total_by_customer(orders):
    """Return a dict mapping each customer to the sum of their totals.
    {"Ana": 31.75, "Ben": 8.0, "Chloe": 37.5}
    """
    ...


def check(label, got, expected):
    print(("PASS" if got == expected else "FAIL"), label, "| got:", repr(got), "| expected:", repr(expected))


if __name__ == "__main__":
    check("customers", customers(ORDERS), ["Ana", "Ben", "Chloe"])
    check("big_orders", [o["customer"] for o in big_orders(ORDERS, 20)], ["Ana", "Chloe"])
    check("total_by_customer", total_by_customer(ORDERS), {"Ana": 31.75, "Ben": 8.0, "Chloe": 37.5})
