"""Exercise 3: reading and writing CSV and JSON files.

Run from inside the week1 folder:  python ex3_files.py
Hint: look up the `csv` module's DictReader and DictWriter, and `json.dump`.
"""
import csv
import json
from pathlib import Path

DATA = Path(__file__).parent / "data"


def read_rows(path):
    """Return the CSV at `path` as a list of dicts (one dict per row)."""
    ...


def write_json(rows, path):
    """Save `rows` to `path` as JSON with indent=2."""
    ...


def check(label, got, expected):
    print(("PASS" if got == expected else "FAIL"), label, "| got:", repr(got), "| expected:", repr(expected))


if __name__ == "__main__":
    rows = read_rows(DATA / "messy_sales.csv")
    check("row count", len(rows or []), 10)
    check("first order id", (rows or [{}])[0].get("order_id"), "1001")
    out = DATA / "ex3_output.json"
    write_json(rows, out)
    check("json round trip", json.loads(out.read_text()) if out.exists() else None, rows)
