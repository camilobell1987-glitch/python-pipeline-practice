"""Exercise 1: functions.

Replace each `...` with your code, then run:  python ex1_functions.py
Every check prints PASS or FAIL so you know where you stand.
"""


def full_name(first, last):
    """Return 'First Last' with each part capitalised.
    full_name("ana", "LOPEZ") -> "Ana Lopez"
    """
    ...


def order_total(quantity, unit_price):
    """Return quantity * unit_price, rounded to 2 decimal places."""
    ...


def apply_discount(total, percent=0):
    """Return the total after taking off `percent` percent, rounded to 2 places.
    apply_discount(100, 10) -> 90.0
    apply_discount(100)     -> 100.0   (percent has a default of 0)
    """
    ...


def check(label, got, expected):
    print(("PASS" if got == expected else "FAIL"), label, "| got:", repr(got), "| expected:", repr(expected))


if __name__ == "__main__":
    check("full_name", full_name("ana", "LOPEZ"), "Ana Lopez")
    check("order_total", order_total(3, 12.5), 37.5)
    check("order_total rounding", order_total(3, 0.1), 0.3)
    check("apply_discount", apply_discount(100, 10), 90.0)
    check("apply_discount default", apply_discount(80), 80.0)
