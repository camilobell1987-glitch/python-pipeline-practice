def full_name(first, last):
    return f"{first.capitalize()} {last.capitalize()}"


def order_total(quantity, unit_price):
    return round(quantity * unit_price, 2)


def apply_discount(total, percent=0):
    return round(total * (1 - percent / 100), 2)
