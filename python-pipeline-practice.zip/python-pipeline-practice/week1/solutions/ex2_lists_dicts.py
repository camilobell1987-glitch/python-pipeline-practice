def customers(orders):
    return sorted({o["customer"] for o in orders})


def big_orders(orders, minimum):
    return [o for o in orders if o["total"] >= minimum]


def total_by_customer(orders):
    totals = {}
    for o in orders:
        totals[o["customer"]] = totals.get(o["customer"], 0) + o["total"]
    return totals
