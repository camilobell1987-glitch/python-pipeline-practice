# Solutions

Try each exercise for at least 20 minutes before looking here. Getting stuck and
searching for the answer is a big part of how you learn this. If you do peek,
close the file and rewrite the code yourself from memory.
