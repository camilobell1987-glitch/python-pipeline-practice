import csv
import json


def read_rows(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def write_json(rows, path):
    with open(path, "w") as f:
        json.dump(rows, f, indent=2)
