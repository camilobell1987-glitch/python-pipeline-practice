def to_number(text):
    try:
        return float(text.strip())
    except ValueError:
        return None


def to_quantity(text):
    try:
        n = int(text.strip())
    except ValueError:
        return None
    return n if n > 0 else None
