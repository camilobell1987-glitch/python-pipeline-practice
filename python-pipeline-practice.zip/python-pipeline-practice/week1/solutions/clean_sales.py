import csv
import sys
from datetime import datetime

from ex4_errors import to_number, to_quantity


def clean_date(text):
    for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(text.strip(), fmt).strftime("%Y-%m-%d")
        except ValueError:
            pass
    return None


def main(input_path, output_path):
    with open(input_path, newline="") as f:
        rows = list(csv.DictReader(f))

    seen, clean, duplicates, skipped = set(), [], 0, 0
    for row in rows:
        oid = row["order_id"]
        if oid in seen:
            duplicates += 1
            continue
        seen.add(oid)

        customer = row["customer"].strip().title()
        quantity = to_quantity(row["quantity"])
        price = to_number(row["unit_price"])
        date = clean_date(row["date"])
        problem = (
            "no customer" if not customer
            else "bad quantity" if quantity is None
            else "bad price" if price is None
            else "bad date" if date is None
            else None
        )
        if problem:
            print(f"Skipped order {oid}: {problem}")
            skipped += 1
            continue

        clean.append({
            "order_id": oid,
            "date": date,
            "customer": customer,
            "product": row["product"].strip().title(),
            "quantity": quantity,
            "unit_price": price,
            "total": round(quantity * price, 2),
        })

    with open(output_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(clean[0]))
        writer.writeheader()
        writer.writerows(clean)

    print(f"Read {len(rows)}, dropped {duplicates} duplicate, skipped {skipped}, wrote {len(clean)}.")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python clean_sales.py INPUT.csv OUTPUT.csv")
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
